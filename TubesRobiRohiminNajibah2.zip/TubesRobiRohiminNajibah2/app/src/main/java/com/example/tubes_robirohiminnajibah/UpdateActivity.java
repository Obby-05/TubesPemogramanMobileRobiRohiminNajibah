package com.example.tubes_robirohiminnajibah;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UpdateActivity extends AppCompatActivity {
    protected Cursor cursor;
    Database database;
    Button btn_simpan;
    EditText nama,jenis,umur,pekerjaan,asal,alamat,notelp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        database = new Database(this);
        nama = findViewById(R.id.Nama);
        jenis = findViewById(R.id.Jenis1);
        umur = findViewById(R.id.Umur1);
        pekerjaan = findViewById(R.id.Pekerjaan1);
        asal = findViewById(R.id.Asal1);
        alamat = findViewById(R.id.Alamat1);
notelp = findViewById(R.id.Notelp1);
        btn_simpan = findViewById(R.id.btn_simpan);
        SQLiteDatabase db = database.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM biodata WHERE nama='" +
                getIntent().getStringExtra("nama")+"'",null);
        cursor.moveToFirst();
        if (cursor.getCount() >0){
            cursor.moveToPosition(0);
            nama.setText(cursor.getString(0).toString());
            jenis.setText(cursor.getString(1).toString());
            umur.setText(cursor.getString(2).toString());
            pekerjaan.setText(cursor.getString(3).toString());
            asal.setText(cursor.getString(4).toString());
            alamat.setText(cursor.getString(5).toString());
            notelp.setText(cursor.getString(6).toString());
        }
        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = database.getWritableDatabase();
                db.execSQL("update biodata set nama='" +
                        nama.getText().toString()+"', jenis='" +
                        jenis.getText().toString()+"',umur='" +
                        umur.getText().toString()+"',pekerjaan='" +
                        pekerjaan.getText().toString()+"' , asal = '" +
                        asal.getText().toString()+"', alamat = '" +
                        alamat.getText().toString()+"', notelp = '" +
                        notelp.getText().toString()+"' where nama='" +
                        getIntent().getStringExtra("nama")+"'");
                Toast.makeText(UpdateActivity.this, "Data Berhasil Di Ubah", Toast.LENGTH_SHORT).show();
            MainActivity.ma.RefreshList();
            finish();
            }
        });
    }
}