package com.example.tubes_robirohiminnajibah;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateActivity extends AppCompatActivity {
protected Cursor cursor;
Database database;
Button btn_simpan;
EditText nama,jenis,umur,pekerjaan,asal,alamat,notelp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
    database = new Database(this);
    nama = findViewById(R.id.Nama);
        jenis = findViewById(R.id.Jenis1);
        umur = findViewById(R.id.Umur1);
        pekerjaan = findViewById(R.id.Pekerjaan1);
        asal = findViewById(R.id.Asal1);
        alamat = findViewById(R.id.Alamat1);
        notelp = findViewById(R.id.Notelp1);
    btn_simpan = findViewById(R.id.btn_simpan);
    btn_simpan.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            SQLiteDatabase db = database.getWritableDatabase();
            db.execSQL("insert into biodata(nama,jenis,umur,pekerjaan,asal,alamat,notelp) values('" +
                    nama.getText().toString()+"', '" +
                    jenis.getText().toString()+"','" +
                    umur.getText().toString()+"','" +
                    pekerjaan.getText().toString()+"','" +
                    asal.getText().toString()+"','" +
                    alamat.getText().toString()+"','" +
                    notelp.getText().toString()+"')");

            Toast.makeText(CreateActivity.this, "Data Berhasil Tersimpan", Toast.LENGTH_SHORT).show();
        MainActivity.ma.RefreshList();
        finish();
        }
    });

    }
}